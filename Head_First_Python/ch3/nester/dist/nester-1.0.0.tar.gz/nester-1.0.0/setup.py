from distutils.core import setup

setup(
	name		=	'nester',
	version		=	'1.0.0',
	py_modules	=	['nester'],
	author		=	'Ramon Gonzalez',
	author_email	=	'rjgonza@gmail.com',
	url		=	'http://rjgonza.com',
	description	= 	'A simple printer of nested lines',
)
